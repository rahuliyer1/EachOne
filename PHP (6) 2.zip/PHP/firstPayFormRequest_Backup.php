<?php
use FDDLL\FirstPayRequest;

require_once 'firstPayRequest.php';
require_once 'AesCipher.php';

class firstPayForm{
    public $resultURL;
    public $amount;
    public $currencyCode;
    public $clientTransactionId;
    public $transactionType;
    public $customerId;
    public $hostedIds;
    public $firstName;
    public $lastName;
    public $middleName;
    public $suffix;
    public $mobileNo;
    public $emailId;
    public $merchantId;
    public $billingAddress_street1;
    public $billingAddress_stree2;
    public $billingAddress_city;
    public $billingAddress_state;
    public $billingAddress_country;
    public $billingAddress_zipcode;
    public $shippingAddress_street1;
    public $shippingAddress_stree2;
    public $shippingAddress_city;
    public $shippingAddress_state;
    public $shippingAddress_country;
    public $shippingAddress_zipcode;
    public $firstPayWalletCode;
    public $firstPayWalletName;
    public $vPAId;
    public $integrationType;
    public $paymentMethodType;
    public $firstPayBankCode;
    public $bankName;
    public $productId;
    public $productDescription;
    public $quantity;
    public $price;
    public $txnAmount;
    public $shippingFee;
    public $discountPrice;
    public $cardNumber;
    public $expMonth;
    public $expYear;
    public $cVV;
    public $nameOnCard;
    public $valutCard;
    public $passengerName;
    public $ticketNo;
    public $issuingCarrier;
    public $flightNo;
    public $travelAgencyName;
    public $travelRoute;
    public $depattureDate;
    public $origin;
    public $destination;
    public $carrrierCode;
    public $serviceClass;
    public $stopoverType;
    public $fareBasisCode;
    public $airlineInvoiceNo;
    public $customerCode;
    public $travelAgencyCode;
    public $depatureTax;
    public $udf1;
    public $udf2;
    public $udf3;
    public $udf4;
    public $udf5;
    public $udf6;
    public $udf7;
    public $udf8;
    public $udf9;
    public $udf10;
    public $key;
    public $iv;
    public $fpURL;
	hhvm.php7.all=true 
hhvm.php7.scalar_types=true 
hhvm.force_hh=true (allows Hack syntax in PHP files)
    
      
    public function __get($property) {
        if (property_exists($this, $property)) {
            return $this->$property;
        }
    }
    
    public function __set($property, $value) {
        if (property_exists($this, $property)) {
            $this->$property = $value;
        }
        
        return $this;
    }
    
 
    public  function __construct() {
            $argv = func_get_args();
           
            switch( func_num_args() ) {
                case 0:
                    self::__construct1();
                    break;              
                case 14:
                    self::__construct2( $argv[0], $argv[1], $argv[2],$argv[3], $argv[4], $argv[5], $argv[6],$argv[7], $argv[8], $argv[9],$argv[10], $argv[11], $argv[12],$argv[13] );
            }
        }
        
        public   function __construct1() {

        }
        
       
  
    
    
    public function __construct2( $merchantId,$key,$iv,$fpURL,$amount,$currencyCode,$clientTransactionId,$transactionType,$firstName,$lastName,$middleName,$mobileNo,$emailId,$resultURL)
    {
        $this->merchantId = $merchantId;
        $this->key = $key;
        $this->iv = $iv;
        $this->fpURL=$fpURL;
        $this->amount = $amount;
        $this->currencyCode  = $currencyCode;
        $this->clientTransactionId = $clientTransactionId;
        $this->transactionType = $transactionType;
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->middleName = $middleName;
        $this->mobileNo = $mobileNo;
        $this->emailId = $emailId;
        $this->resultURL = $resultURL;
        $this->integrationType = "";
    }
    public static function object_2_array($result)
    {
        $array = array();
        foreach ($result as $key=>$value)
        {
            # if $value is an array then
            if (is_array($value))
            {
                #you are feeding an array to object_2_array function it could potentially be a perpetual loop.
                $array[$key]=firstPayForm::object_2_array($value);
            }
            
            # if $value is not an array then (it also includes objects)
            else
            {
                # if $value is an object then
                if (is_object($value))
                {
                    $array[$key]=firstPayForm::object_2_array($value);
                } else {
                    if(!is_null($value))
                        $array[$key]=$value;
                }
            }
        }
        return $array;
    }
    public function calcHmac(string $data, string $Key)
    {
		print_r('HERE ');
		print_r("HERE ");
		//return "ABCDEF";
        return hash_hmac('sha512',$data,$Key);
    }
    
    public static function curlCall($merchantID,$encryptData,$url,$hmacCode=''){
        $curl = curl_init();
        if (!$curl) {
            die("Couldn't initialize a cURL handle");
        }
        
        if(isset($hmacCode)&&!empty($hmacCode)){
            $headers = array(
                'Content-Type: application/json',
                'HMAC:'.$hmacCode,
                'merchantid:'.$merchantID
            );
        }else {
            $headers = array(
                'Content-Type: application/json',
                'merchantid:'.$merchantID
            );
        }
        curl_setopt($curl, CURLOPT_HTTPHEADER,$headers);
        
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_POSTFIELDS, $encryptData);
        curl_setopt($curl, CURLINFO_HEADER_OUT, true);
        // OPTIONS:
        curl_setopt($curl, CURLOPT_URL, $url);
        
        // EXECUTE:
        $result = curl_exec($curl);
        
        
        
        // Check if any error has occurred
        if (curl_errno($curl))
        {
            echo 'cURL error: ' . curl_error($curl);
        }
        else
        {
            // cURL executed successfully
            //  print_r(curl_getinfo($curl));
        }
        if(!$result){die("Connection Failure");}
        curl_close($curl);
        return $result;
    }
    
    public function sale($bsObj) { 
       
        echo 'Current PHP version: ' . phpversion();
        $firstPayObj = new FirstPayRequest($bsObj);        
        
        $bsArray = firstPayForm::object_2_array($firstPayObj);        
       // var_dump($bsArray); 
		
        foreach ($bsArray as $key=>$val){
            if(is_array($val)){
                if(count($val) == 0){               
                    unset($bsArray[$key]);
                }else{
                    foreach ($val as $key1=>$val1){
                        if(is_array($val1)){
                            if(count($val1) == 0){
                                unset($bsArray[$key][$key1]);
                            }
                            
                        }
                    }
                }
            }
        }
		
			
		$tp = "------------------------------------";
		///var_dump($tp);
		
        $bsObj1 = json_decode(json_encode($bsArray), FALSE);
		
		echo '<br/>';
			echo '<br/>';
        print_r($bsObj1);
			echo '<br/>';
				echo '<br/>';
					echo '<br/>';
      
	  
        $getTokenJson = (json_encode($bsObj1,JSON_UNESCAPED_SLASHES));
      //  var_dump($getTokenJson); 
        $key = $bsObj->key;
		//var_dump($key);
			echo '<br/>';
		print_r($key);
		
		
        //$key = base64_decode($key);
        $iv = $bsObj->iv;
        //$iv = base64_decode($iv);
        $url = $bsObj->fpURL;
        $merchantID = $bsObj->merchantId;
		
		//print_r($tp);
			echo '<br/>';
		//var_dump($key);
		print_r($iv);
        
        $AesCipher = new \AesCipher();
		
		
		//var_dump($getTokenJson);
			echo '<br/>';
		print_r($getTokenJson);
      
        
        $encryptData = $AesCipher->encrypt($key, $iv, $getTokenJson);
        $encryptedPayload ='{"encryptData":'.'"'. $encryptData.'"}';
		//var_dump($encryptData);
			print_r($tp);
		print_r($encryptData);
		
		echo '<br/>';echo '<br/>';echo '<br/>';
		echo var_dump(is_string($encryptData));
		echo var_dump(is_string($bsObj->key));
		print_r("BEFORE CALLING HMAC ");
		
			
		$s2 = new string();
		$s3 = new string();
		//$hmacCode = new string();

		$s2=$encryptData;
		$s3 = $bsObj->key;
		
		echo var_dump(is_string($s2));
		echo var_dump(is_string($s3));
		echo '<br/>';echo '<br/>';echo '<br/>';
			print_r($s2);
				print_r($s3);
				
				$firstPayForm1 = new firstPayForm();
		
		 //$hmacCode = firstPayForm::calcHmac($encryptData,"CNy+HimxmI4PmrJWrpLarBfbo6jIY/CHcezg2VQ8u5o=");
       $hmacCode = firstPayForm::calcHmac($encryptData,$bsObj->key);
	  //  $hmacCode = $firstPayForm1->calcHmac($s2,$s3);
	   //$hmacCode = $firstPayForm1->calcHmac($encryptData,$bsObj->key);
       var_dump($hmacCode);  //exit;
	   print_r($hmacCode);
        return firstPayForm::curlCall($merchantID,$encryptedPayload,$url,$hmacCode);
    }
    
    public function refund_inquiry($firstPayRefundRequest) {
        
      /*  $bsArray = firstPayForm::object_2_array($firstPayRefundRequest);
        
        
        foreach ($bsArray as $key=>$val){
            if(is_array($val))
                if(count($val) == 0){
                    unset($bsArray[$key]);
            }
        }*/
 
        $bsObj2 = json_decode(json_encode($firstPayRefundRequest), FALSE);
  
        $firstPayRefundRequestJson = (json_encode($bsObj2,JSON_UNESCAPED_SLASHES));
        
        $key = $firstPayRefundRequest->key;
        $key = base64_decode($key);
        $iv = $firstPayRefundRequest->iv;
        $iv = base64_decode($iv);
        $url = $firstPayRefundRequest->fpURL;
        $merchantID = $firstPayRefundRequest->merchantId;
        
        $AesCipher = new \AesCipher();
        
        $encryptData =  $AesCipher->encrypt($key, $iv, $firstPayRefundRequestJson);
        
        return firstPayForm::curlCall($merchantID,$encryptData,$url);
        
    }
}

	class string { }