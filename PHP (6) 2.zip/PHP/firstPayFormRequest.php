<?php
use FDDLL\FirstPayRequest;

require_once 'firstPayRequest.php';
require_once 'AesCipher.php';

class firstPayForm{
    public $resultURL;
    public $amount;
    public $currencyCode;
    public $clientTransactionId;
    public $transactionType;
    public $customerId;
    public $hostedIds;
    public $firstName;
    public $lastName;
    public $middleName;
    public $suffix;
    public $mobileNo;
    public $emailId;
    public $merchantId;
    public $billingAddress_street1;
    public $billingAddress_stree2;
    public $billingAddress_city;
    public $billingAddress_state;
    public $billingAddress_country;
    public $billingAddress_zipcode;
    public $shippingAddress_street1;
    public $shippingAddress_stree2;
    public $shippingAddress_city;
    public $shippingAddress_state;
    public $shippingAddress_country;
    public $shippingAddress_zipcode;
    public $firstPayWalletCode;
    public $firstPayWalletName;
    public $vPAId;
    public $integrationType;
    public $paymentMethodType;
    public $firstPayBankCode;
    public $bankName;
    public $productId;
    public $productDescription;
    public $quantity;
    public $price;
    public $txnAmount;
    public $shippingFee;
    public $discountPrice;
    public $cardNumber;
    public $expMonth;
    public $expYear;
    public $cVV;
    public $nameOnCard;
    public $valutCard;
    public $passengerName;
    public $ticketNo;
    public $issuingCarrier;
    public $flightNo;
    public $travelAgencyName;
    public $travelRoute;
    public $depattureDate;
    public $origin;
    public $destination;
    public $carrrierCode;
    public $serviceClass;
    public $stopoverType;
    public $fareBasisCode;
    public $airlineInvoiceNo;
    public $customerCode;
    public $travelAgencyCode;
    public $depatureTax;
    public $udf1;
    public $udf2;
    public $udf3;
    public $udf4;
    public $udf5;
    public $udf6;
    public $udf7;
    public $udf8;
    public $udf9;
    public $udf10;
    public $key;
    public $iv;
    public $fpURL;

      
    public function __get($property) {
        if (property_exists($this, $property)) {
            return $this->$property;
        }
    }
    
    public function __set($property, $value) {
        if (property_exists($this, $property)) {
            $this->$property = $value;
        }
        
        return $this;
    }
    
 
    public  function __construct() {
            $argv = func_get_args();
           
            switch( func_num_args() ) {
                case 0:
                    self::__construct1();
                    break;  
				 case 17:
                    self::__construct2( $argv[0], $argv[1], $argv[2],$argv[3], $argv[4], $argv[5], $argv[6],$argv[7], $argv[8], $argv[9],$argv[10], $argv[11], $argv[12],$argv[13], $argv[14], $argv[15], $argv[16]);
					break;	
                case 14:
                    self::__construct3( $argv[0], $argv[1], $argv[2],$argv[3], $argv[4], $argv[5], $argv[6],$argv[7], $argv[8], $argv[9],$argv[10], $argv[11], $argv[12],$argv[13]);
            }
        }
        
        public   function __construct1() {

        }
        
       
  
    
    
    public function __construct2( $merchantId,$key,$iv,$fpURL,$amount,$currencyCode,$clientTransactionId,$transactionType,$firstName,$lastName,$middleName,$mobileNo,$emailId,$resultURL,$paymentMethodType,$integrationType,$vPAId)
    {
		
        $this->merchantId = $merchantId;
        $this->key = $key;
        $this->iv = $iv;
        $this->fpURL=$fpURL;
        $this->amount = $amount;
        $this->currencyCode  = $currencyCode;
        $this->clientTransactionId = $clientTransactionId;
        $this->transactionType = $transactionType;
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->middleName = $middleName;
        $this->mobileNo = $mobileNo;
        $this->emailId = $emailId;
        $this->resultURL = $resultURL;
        $this->paymentMethodType = $paymentMethodType;
        $this->integrationType = $integrationType;
        $this->vPAId = $vPAId;
       
        
        
        
        
    }
	
	public function __construct3( $merchantId,$key,$iv,$fpURL,$amount,$currencyCode,$clientTransactionId,$transactionType,$firstName,$lastName,$middleName,$mobileNo,$emailId,$resultURL)
    {
		
        $this->merchantId = $merchantId;
        $this->key = $key;
        $this->iv = $iv;
        $this->fpURL=$fpURL;
        $this->amount = $amount;
        $this->currencyCode  = $currencyCode;
        $this->clientTransactionId = $clientTransactionId;
        $this->transactionType = $transactionType;
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->middleName = $middleName;
        $this->mobileNo = $mobileNo;
        $this->emailId = $emailId;
        $this->resultURL = $resultURL;
       
    }
    public static function object_2_array($result)
    {
        $array = array();
        foreach ($result as $key=>$value)
        {
            # if $value is an array then
            if (is_array($value))
            {
                #you are feeding an array to object_2_array function it could potentially be a perpetual loop.
                $array[$key]=firstPayForm::object_2_array($value);
            }
            
            # if $value is not an array then (it also includes objects)
            else
            {
                # if $value is an object then
                if (is_object($value))
                {
                    $array[$key]=firstPayForm::object_2_array($value);
                } else {
                    if(!is_null($value))
                        $array[$key]=$value;
                }
            }
        }
        return $array;
    }
    public static function calcHmac(string $data, string $Key)
    {
        return hash_hmac('sha512',$data,$Key);
    }
    
    public static function curlCall($merchantID,$encryptData,$url,$hmacCode=''){
        $curl = curl_init();
        if (!$curl) {
            die("Couldn't initialize a cURL handle");
        }
      //  echo 'cURL Initialized ';
        if(isset($hmacCode)&&!empty($hmacCode)){
            $headers = array(
                'Content-Type: application/json',
                'HMAC:'.$hmacCode,
                'merchantid:'.$merchantID
            );
        }else {
            $headers = array(
                'Content-Type: application/json',
                'merchantid:'.$merchantID
            );
        }
		echo "\n";
		//echo 'HEADERS : ' . $hmacCode ;
		//echo 'HEADERS : ' . $merchantID ;
		echo "\n";
        curl_setopt($curl, CURLOPT_HTTPHEADER,$headers);
        
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_POSTFIELDS, $encryptData);
        curl_setopt($curl, CURLINFO_HEADER_OUT, true);
        // OPTIONS:
        curl_setopt($curl, CURLOPT_URL, $url);
        
        // EXECUTE:
        $result = curl_exec($curl);
        
        echo "\n Response Data:  \n "; //. $result;
        //echo $result;
        // Check if any error has occurred
        if (curl_errno($curl))
        {
            echo 'cURL error: ' . curl_error($curl);
        }
        else
        {
            // cURL executed successfully
            //  print_r(curl_getinfo($curl));
        }
        if(!$result){die("Connection Failure");}
        curl_close($curl);
        return $result;
    }
    
    public function sale($bsObj) { 
       
        
        $firstPayObj = new FirstPayRequest($bsObj);        
        
        $bsArray = firstPayForm::object_2_array($firstPayObj);        
        
        foreach ($bsArray as $key=>$val){
            if(is_array($val)){
                if(count($val) == 0){               
                    unset($bsArray[$key]);
                }else{
                    foreach ($val as $key1=>$val1){
                        if(is_array($val1)){
                            if(count($val1) == 0){
                                unset($bsArray[$key][$key1]);
                            }
                            
                        }
                    }
                }
            }
        }
      
        $bsObj1 = json_decode(json_encode($bsArray), FALSE);
        
        $getTokenJson = (json_encode($bsObj1,JSON_UNESCAPED_SLASHES));
		
	
        $key = $bsObj->key;
		
		
        $key = base64_decode($key);
			
		$iv = $bsObj->iv;
		
        $iv = base64_decode($iv);
		
        $url = $bsObj->fpURL;
		
        $merchantID = $bsObj->merchantId;
		
        $AesCipher = new \AesCipher();
       // MerchantId+MerchantTxnId+Amount+CurrencyCode+Key
		$hmacString= $merchantID.$bsObj->clientTransactionId.$bsObj->amount.$bsObj->currencyCode.$bsObj->key;
		
		$encryptData =  $AesCipher->encrypt($key, $iv, $getTokenJson);
        $encryptedPayload ='{"encryptData":'.'"'. $encryptData.'"}';
   
        $hmacCode = firstPayForm::calcHmac($hmacString,$bsObj->key);
		
        return firstPayForm::curlCall($merchantID,$encryptedPayload,$url,$hmacCode);
    }
    
   /* public function refund_inquiry($bsObj) {
	   
	   $firstPayObj = new FirstPayRequest($bsObj);  
        
        $bsArray = firstPayForm::object_2_array($firstPayObj);
        
        
        foreach ($bsArray as $key=>$val){
            if(is_array($val)){
                if(count($val) == 0){               
                    unset($bsArray[$key]);
                }else{
                    foreach ($val as $key1=>$val1){
                        if(is_array($val1)){
                            if(count($val1) == 0){
                                unset($bsArray[$key][$key1]);
                            }
                            
                        }
                    }
                }
            }
        }
        
 
        $bsObj2 = json_decode(json_encode($bsArray), FALSE);
  
        $firstPayRefundRequestJson = (json_encode($bsObj2,JSON_UNESCAPED_SLASHES));
        
        $key = $bsObj->key;
        $key = base64_decode($key);
        $iv = $bsObj->iv;
        $iv = base64_decode($iv);
        $url = $bsObj->fpURL;
        $merchantID = $bsObj->merchantId;
        $merchantTxnId = $bsObj->merchantTxnId;
        $fpTransactionId = $bsObj->fpTransactionId;
        $refundAmount = $bsObj->refundAmount;
		
        $AesCipher = new \AesCipher();
        
        $encryptData =  $AesCipher->encrypt($key, $iv, $firstPayRefundRequestJson);
       
		if (isset($bsObj->refundAmount)) {
			$hmacString= $merchantID.$bsObj->merchantTxnId.$bsObj->refundAmount.$bsObj->key;
			} else {
				$hmacString= $merchantID.$bsObj->merchantTxnId.$bsObj->key;
			}
        
		$hmacCode = firstPayForm::calcHmac($hmacString,$bsObj->key);
		$encryptedPayload ='{"encryptData":'.'"'. $encryptData.'"}';
		return firstPayForm::curlCall($merchantID,$encryptedPayload,$url,$hmacCode);
		
        
    }*/
	
	public function inquiry($FirstPayInquiryRequest) {
        
        $bsArray = firstPayForm::object_2_array($FirstPayInquiryRequest);
        
        
        foreach ($bsArray as $key=>$val){
            if(is_array($val)){
                if(count($val) == 0){               
                    unset($bsArray[$key]);
                }else{
                    foreach ($val as $key1=>$val1){
                        if(is_array($val1)){
                            if(count($val1) == 0){
                                unset($bsArray[$key][$key1]);
                            }
                            
                        }
                    }
                }
            }
        }
        
 
        $bsObj2 = json_decode(json_encode($FirstPayInquiryRequest), FALSE);
  
        $FirstPayInquiryRequestJson = (json_encode($bsObj2,JSON_UNESCAPED_SLASHES));
        
        $key = $FirstPayInquiryRequest->key;
        $key = base64_decode($key);
        $iv = $FirstPayInquiryRequest->iv;
        $iv = base64_decode($iv);
        $url = $FirstPayInquiryRequest->fpURL;
        $merchantID = $FirstPayInquiryRequest->merchantId;
        $merchantTxnId = $FirstPayInquiryRequest->merchantTxnId;
        $fpTransactionId = $FirstPayInquiryRequest->fpTransactionId;
        
		
        $AesCipher = new \AesCipher();
        
        $encryptData =  $AesCipher->encrypt($key, $iv, $FirstPayInquiryRequestJson);
        $hmacString= $merchantID.$bsObj2->merchantTxnId.$bsObj2->key;
		
        
		$hmacCode = firstPayForm::calcHmac($hmacString,$bsObj2->key);
		$encryptedPayload ='{"encryptData":'.'"'. $encryptData.'"}';
		return firstPayForm::curlCall($merchantID,$encryptedPayload,$url,$hmacCode);
		
        
    }
	public function refund($firstPayRefundRequest) {
        
        $bsArray = firstPayForm::object_2_array($firstPayRefundRequest);
        
        
        foreach ($bsArray as $key=>$val){
            if(is_array($val)){
                if(count($val) == 0){               
                    unset($bsArray[$key]);
                }else{
                    foreach ($val as $key1=>$val1){
                        if(is_array($val1)){
                            if(count($val1) == 0){
                                unset($bsArray[$key][$key1]);
                            }
                            
                        }
                    }
                }
            }
        }
        
 
        $bsObj2 = json_decode(json_encode($firstPayRefundRequest), FALSE);
  
        $firstPayRefundRequestJson = (json_encode($bsObj2,JSON_UNESCAPED_SLASHES));
        
        $key = $firstPayRefundRequest->key;
        $key = base64_decode($key);
        $iv = $firstPayRefundRequest->iv;
        $iv = base64_decode($iv);
        $url = $firstPayRefundRequest->fpURL;
        $merchantID = $firstPayRefundRequest->merchantId;
        $merchantTxnId = $firstPayRefundRequest->merchantTxnId;
        $fpTransactionId = $firstPayRefundRequest->fpTransactionId;
        $refundAmount = $firstPayRefundRequest->refundAmount;
		
        $AesCipher = new \AesCipher();
        
        $encryptData =  $AesCipher->encrypt($key, $iv, $firstPayRefundRequestJson);
    
		$hmacString= $merchantID.$bsObj2->merchantTxnId.$bsObj2->refundAmount.$bsObj2->key;
		
        
		$hmacCode = firstPayForm::calcHmac($hmacString,$bsObj2->key);
		$encryptedPayload ='{"encryptData":'.'"'. $encryptData.'"}';
		return firstPayForm::curlCall($merchantID,$encryptedPayload,$url,$hmacCode);
		
        
    }
}