<?php
$fpTxnId=$_GET['fpTxnId'];
$encData=$_GET['encData'];
$merchantId=$_GET['merchantId'];
//echo $merchantId.'+++++++++';
//echo $fpTxnId." ".$encData."+++++++++ ".$merchantId;exit;


include("firstPayResult.php");

$bsObj = new \firstPayResult($merchantId, $encData,$fpTxnId);
$getJson = (json_encode($bsObj,JSON_UNESCAPED_SLASHES));

$response =  $bsObj->curlCall($merchantId,$getJson,'https://test.fdconnect.com/FirstPayL2Services/decryptMerchantResponse');

$jsonObject = json_decode($response,true);

//print_r($jsonObject);
//echo "transactionStatus=".$jsonObject['transactionStatus'];


 if(isset($jsonObject['transactionStatus'])){
	
	
	echo "<br><table border=\"1\" ><br>";
	foreach($jsonObject as $key => $value){
		echo "<tr>";
		echo "<td style='background-color: #4CAF50; color: white;'>".$key."</td>";
		echo "<td style='background-color: rgb(217, 247, 207); color: darkgreen;'>".$value."</td>";
		echo "</tr>";
	}
	echo "<br></table><br>";
	die;
 }
?>

<div class="row">
<div class="col-75">
<div class="container">

<h1 style="background-color: darkgreen; color: white;">Response Data:</h1>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method = "post">
    
    <div class="row">
    	<div class="col-50">
            <h3>FIRSTPAY - SAMPLE MERCHANT</h3>
            <?php if($jsonObject ["transactionStatus"]=="SUCCESS"){?>
            <div class="row">
                <div class="col-50">
                <label for="fname"><i class="fa fa-user"></i> Thank you shopping with us!</label>
              
                </div>
                <div class="col-50">
                <label for="zip">Your order details has been sent on your registered email ID....</label>
                 <label for="zip">Order ID : <?php echo $jsonObject['merchantTxnId'];?></label>
                 <label for="zip">Order Amount : <?php echo $jsonObject['transactionAmount'];?></label>
                </div>
            </div> 
            <?php } else
        {
          ?>
             <div class="row">
                <div class="col-50">
                <label for="fname"><i class="fa fa-user"></i> Something went wrong!</label>
              
                </div>
                <div class="col-50">
                <label for="zip">Your order is cancelled please try again later....</label>
                
                </div>
            </div> 
            <?php }?>
        </div>
    </div>
    
    <input type="text" value="Happy Shopping" class="btn" name="submit">
    </form>
    </div>
    </div>
    
    
    </div>
   <style>
h1,td,input,div,textarea,button {
   
  background-color: #4CAF50; 
  color: white;
  
 
}

 input {
        width: 85%; /* Set the table's width to 100% of its container */
    }
 table {
        width: 75%; /* Set the table's width to 100% of its container */
    }
 select {
        width: 10%; /* Set the table's width to 100% of its container */
    }
    }
</style>