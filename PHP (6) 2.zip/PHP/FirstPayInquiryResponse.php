<?php

    class InquiryTxnDetailList
    {
        public $fpTxnId;
        public $merchantId;
        public $merchantTxnId;
        public $baseAmount;
        public $txnStatus;
        public $txnDescription;
        public $txnType;
        public $externalOrderTokenId;
        public $channel;
        public $currency;
        public $txnDate;
        public $balanceAmount;
        public $retryCount;
        public $tranEnquiryCount;
        public $isBalanceChange;
        
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
    }
    
   
    class RootObject
    {
        public $inquiryTxnDetailList;
        public function __get($property) {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }
        
        public function __set($property, $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
            
            return $this;
        }
    }
 