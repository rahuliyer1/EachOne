<?php

namespace PaymentGateway;
require_once 'FirstPayRefundRequest.php';
require_once 'FirstPayInquiryRequest.php';
require_once 'FirstPayRefundResponse.php';
require_once 'FirstPayInquiryResponse.php';
require_once('firstPayFormRequest.php');
$firstPayRefundRequest =  new FirstPayRefundRequest();
$firstPayInquiryRequest = new FirstPayInquiryRequest();



$bsObj = new \firstPayForm();

$firstPayInquiryRequest->merchantTxnId = "20231018212025";
$firstPayInquiryRequest->fpTransactionId = "2023101815090030";


$firstPayInquiryRequest->key = "kCTAu4TOmirjC0BiJXuM3wORDsm03ITpsDpZYbZ0TTE=";
$firstPayInquiryRequest->iv = "dLZmkqqFBGmnJ2LtLIY0fA==";
$firstPayInquiryRequest->merchantId = "470000000255972";
$firstPayInquiryRequest->fpURL ='https://www.fdconnect.com/FDConnectL3Services/getTxnInquiryDetail';
//echo "Request Data:";
//var_dump($firstPayInquiryRequest);

 $response1 = new \RootObject();



// Convert request data to a properly formatted JSON-like string for debugging
$requestDataJSON = json_encode($firstPayInquiryRequest, JSON_PRETTY_PRINT);

// Display the properly formatted JSON-like request data
echo "\nRequest Data:\n" . $requestDataJSON . "\n";

// Make the API call and decode the JSON response
$response1 = json_decode($bsObj->inquiry($firstPayInquiryRequest));

// Check if there was an error decoding the JSON
if (json_last_error() !== JSON_ERROR_NONE) {
    echo "Error decoding JSON response: " . json_last_error_msg();
} else {
    // Access the properties of the decoded JSON response
    echo "API Response:\n";
    var_dump($response1);
}


?>