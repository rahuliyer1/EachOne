<?php
class firstPayResult{
    public $merchantId;
    public $encData;
    public $fpTxnId;
    public function __get($property) {
        if (property_exists($this, $property)) {
            return $this->$property;
        }
    }
    
    public function __set($property, $value) {
        if (property_exists($this, $property)) {
            $this->$property = $value;
        }
        
        return $this;
    }
    public function __construct($merchantId,$encData,$fpTxnId)
    {
        
        $this->merchantId = $merchantId;
        $this->encData = $encData;
        $this->fpTxnId = $fpTxnId;
    }
    
    public function curlCall($merchantID,$encryptData,$url){
        $curl = curl_init();
        if (!$curl) {
            die("Couldn't initialize a cURL handle");
        }
        
       
        $headers = array(
            'Content-Type: application/json',
            'merchantid:'.$merchantID
        );
        
        curl_setopt($curl, CURLOPT_HTTPHEADER,$headers);
        
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_POSTFIELDS, $encryptData);
        curl_setopt($curl, CURLINFO_HEADER_OUT, true);
        // OPTIONS:
        curl_setopt($curl, CURLOPT_URL, $url);
        
        // EXECUTE:
        $result = curl_exec($curl);
        
        
        
        // Check if any error has occurred
        if (curl_errno($curl))
        {
            echo 'cURL error: ' . curl_error($curl);
        }
        else
        {
            // cURL executed successfully
            //  print_r(curl_getinfo($curl));
        }
        if(!$result){die("Connection Failure");}
        curl_close($curl);
        return $result;
    }
    
}
