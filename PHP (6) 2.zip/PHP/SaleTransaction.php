<?php
require_once('firstPayFormRequest.php');
require_once 'firstPayResponse.php';



if (isset($_POST['submit']) && !empty($_POST['clientid'])) {
    $randnum = mt_rand(10000000, 99999999);
    $response = new \FristPayResponse();
    //$bsObj = new \firstPayForm($_POST['merchantId'], $_POST['key'], $_POST['iv'], $_POST['env'], $_POST['amount'], "INR", $_POST['clientid'], "SALE", "ABC", "XYZ", "DEF", "7666492785", "sunil.jaiswar@fiserv.com", $_POST['resulturl'], "UPI", "MERCHANT_PAYMENT_MODE_INTEGRATION", "test@okicici");
//MERCHANT_PAYMENT_MODE_BANKORWALLET_INTEGRATION - MERCHANT_PAYMENT_MODE_INTEGRATION
	 $bsObj = new \firstPayForm($_POST['merchantId'], $_POST['key'], $_POST['iv'], $_POST['env'], $_POST['amount'], "INR", $_POST['clientid'], "SALE", "ABC", "XYZ", "DEF", "7666492785", "sunil.jaiswar@fiserv.com", $_POST['resulturl']);
    $response = json_decode($bsObj->sale($bsObj));

    if (isset($response->response->sessionTokenId)) {
        $sessiontokenID = $response->response->sessionTokenId;
        $configID = $_POST['pageid'];
        $redirectURL = $_POST['redirecturl'] . "?sessionToken=" . $sessiontokenID . "&configId=" . $configID;
        
        // Redirect to resultDecoder.php for response decoding
        header("Location: " . $redirectURL);
    } else {
        echo "Something went wrong............";
        var_dump($response);
    }
}
function getDateTime()
{
	date_default_timezone_set('Asia/Kolkata');
	global $dateTime;
    $dateTime = date("YmdHis");
	return $dateTime;
}
?>
 <h1 align="center">Sale Transaction Request:</h1>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
  <table>

    <tr>
      <td>
        <label for="transactiontype">Transaction Type</label>
      </td>
      <td>
        <input type="text" id="transactiontype" name="transactiontype" placeholder="Sale" value="Sale" readonly>
      </td>
    </tr>
    <tr>
      <td>
        <label for="merchantidd">Merchant ID</label>
      </td>
	  <td> <input type="text" id="merchantId" name="merchantId" value=""  >
        <select id="merchantidd" name="merchantidd">
          <option value="" selected>Select MID...</option>
          <option value="470000000255972">470000000255972_PROD</option>
          <option value="470000014671551">470000014671551_UAT</option>
          <option value="470000096003134">470000096003134_UAT</option>
        </select>
		
      </td>
    </tr>
    <tr>
      <td>
        <label for="clientid">Client Transaction Id</label>
      </td>
      <td>
        <input type="text" id="clientid" name="clientid" value="<?php echo getDateTime(); ?>">
      </td>
    </tr>
    <tr>
      <td>
        <label for="amount">Amount</label>
      </td>
      <td>
        <input type="text" id="amount" name="amount" value="1.5">
      </td>
    </tr>
    <tr>
      <td>
        <label for="currency">Currency Code</label>
      </td>
      <td>
        <input type="text" id="currency" name="currency" value="INR" readonly>
      </td>
    </tr>
    <tr>
      <td>
        <label for="pageid">Page ID / Config ID</label>
      </td>
      <td>
        <input type="text" id="pageid" name="pageid" value="">
      </td>
    </tr>
    <tr>
      <td>
        <label for="key">Transaction_Key</label>
      </td>
      <td>
        <input type="text" id="key" name="key" value="">
      </td>
    </tr>
    <tr>
      <td>
        <label for="iv">Transaction_IV</label>
      </td>
      <td>
        <input type="text" id="iv" name="iv" value="">
      </td>
    </tr>
    <tr>
      <td>
        <label for="resulturl">Result_URL</label>
      </td>
      <td>
        <input type="text" id="resulturl" name="resulturl" value="">
      </td>
    </tr>
    <tr>
      <td>
        <label for="env">Environment</label>
      </td>
      <td>
        <input type="text" id="env" name="env" value="">
      </td>
    </tr>
    <tr>
      <td>
        <label for="redirecturl">Redirect_url</label>
      </td>
      <td>
        <input type="text" id="redirecturl" name="redirecturl" value="">
      </td>
    </tr>
    <tr>
      <td colspan="2">
        <input type="submit" value="Continue to checkout" class="btn" name="submit">
      </td>
    </tr>
  </table>
</form>
<!--
<div id="response-container" style="position: relative;">
    <textarea id="response-textarea" rows="25" style="width: 100%;">Transaction Response: </textarea>
	<button type="button" onclick="copyToClipboard('response-textarea', this)" style="position: absolute; bottom: 0; right: 0;">Copy</button>
</div>
<button type="button" id="clearResponse" onclick="clearResponse()">Clear Response</button> -->
<style>
h1,td,input,div,textarea,button {
   
  background-color: #4CAF50; 
  color: white;
  
 
}

 input {
        width: 85%; /* Set the table's width to 100% of its container */
    }
 table {
        width: 75%; /* Set the table's width to 100% of its container */
    }
 select {
        width: 10%; /* Set the table's width to 100% of its container */
    }
    }
</style>

        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/3.1.9-1/crypto-js.min.js" />
		   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

<script type="text/javascript">
	     
		function dsstore() 
		{
                var mid = document.getElementById("merchantidd");
                var displayedmid=mid.options[mid.selectedIndex].value;
                document.getElementById("merchantid").value=displayedmid;
                
				var pageId = document.getElementById("pageidd");
                var displayedpageId=pageId.options[pageId.selectedIndex].value;
                document.getElementById("pageid").value=displayedpageId;
				
				var Key = document.getElementById("keyy");
                var displayedKey=Key.options[Key.selectedIndex].value;
                document.getElementById("key").value=displayedKey;
                
				var Ivv = document.getElementById("ivv");
                var displayedIvv=Ivv.options[Ivv.selectedIndex].value;
                document.getElementById("iv").value=displayedIvv;
                
			   
			   
		}
		
		document.getElementById("merchantidd").addEventListener("change", function () {
    var selectedStore = this.value;
    
    var merchantIdField = document.getElementById("merchantId");
    var pageidField = document.getElementById("pageid");
    var keyField = document.getElementById("key");    
    var ivField = document.getElementById("iv");
    var resulturlField = document.getElementById("resulturl");
    var redirecturlField = document.getElementById("redirecturl");
    var envField = document.getElementById("env");
   
console.log("Selected MID:", selectedStore);
    if (selectedStore === "470000000255972") {
        merchantIdField.value = "470000000255972";
		pageidField.value = "PageId2019120415869";		
        keyField.value = "kCTAu4TOmirjC0BiJXuM3wORDsm03ITpsDpZYbZ0TTE=";
        ivField.value = "dLZmkqqFBGmnJ2LtLIY0fA==";
        resulturlField.value = "http://127.0.0.1:8080/PHP/sampleTestResultprod.php";
        redirecturlField.value = "https://www.fdconnect.com/Pay/";
        envField.value = "https://www.fdconnect.com/FDConnectL3Services/getToken";

    } else if (selectedStore === "470000014671551") {
        merchantIdField.value = "470000014671551";
		pageidField.value = "PageId2022021713165";
        keyField.value = "d+jmahjqZzygfVmhZdyeOuzB4SuT7r7n2FYIo1/61F8=";
        ivField.value = "QXz06BpZP9K82LVIl2i6qA==";
        resulturlField.value = "http://127.0.0.1:8080/PHP/sampleTestResultuat.php";
        redirecturlField.value = "https://test.fdconnect.com/Pay/";
        envField.value = "https://test.fdconnect.com/FirstPayL2Services/getToken";
       
    } else if (selectedStore === "470000096003134") {
        merchantIdField.value = "470000096003134";
		pageidField.value = "PageId2023080744387";
        keyField.value = "ttQGgC0XaDFitx8UVKAhF5FF/Nbn7/H2n7xOPLLPO78=";
        ivField.value = "Gl2lL5tdTOObtvS49224hA==";
        resulturlField.value = "http://127.0.0.1:8080/PHP/sampleTestResultuat.php";
        redirecturlField.value = "https://test.fdconnect.com/Pay/";
        envField.value = "https://test.fdconnect.com/FirstPayL2Services/getToken";
       
    }
	else {
        merchantIdField.value = "";
        pageidField.value = "";
        keyField.value = "";
        ivField.value = "";
        resulturlField.value = "";
        redirecturlField.value = "";
        envField.value = "";
    }
   
});
            
</script>
