<?php
require_once('firstPayFormRequest.php');
require_once 'firstPayResponse.php';
if(isset($_POST['submit']) && !empty($_POST['clientid']))
{
    $randnum = mt_rand(10000000, 99999999);
    $response = new \FristPayResponse();
    $bsObj = new \firstPayForm($_POST['merchantId'], $_POST['key'], $_POST['iv'],$_POST['env'] ,$_POST['amount'], "INR",$_POST['clientid'], "SALE","ABC", "XYZ", "DEF", "7666492785", "sunil.jaiswar@fiserv.com", $_POST['resulturl']); 
    
    $response = json_decode($bsObj->sale($bsObj));
    
    if(isset($response->response->sessionTokenId)){
		
        $sessiontokenID = $response->response->sessionTokenId;
        
        $configID=$_POST['pageid'];
        $redirectURL = $_POST['redirecturl']."?sessionToken=".$sessiontokenID."&configId=".$configID;
        
        header("Location:$redirectURL");
    }else{
        
        echo "Something went wrong............";
		print $response;
		
    }
    
}
function getDateTime()
{
	date_default_timezone_set('Asia/Kolkata');
	global $dateTime;
    $dateTime = date("YmdHis");
	return $dateTime;
}
?>
<div class="row">
  <div class="col-75">
    <div class="container">
      <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method = "post">

        <div class="row">
          <div class="col-50">
            <h3>Sale Transaction Request: </h3>
            
            <div class="row">
              <div class="col-50">
               <label for="fname"><i class="fa fa-user"></i> Transaction Type</label>
               <input type="text" id="transactiontype" name="transactiontype" placeholder="Sale" value="Sale" readonly>
              </div>
              <div class="col-50">
                <label for="zip">Merchant ID</label>
				<select id="merchantidd" name="merchantidd">
						<option value="" selected>Select MID...</option>
                        <option value="470000000255972" >470000000255972_PROD</option>
                        <option value="470000014671551" >470000014671551_UAT</option>
				 </select>
                <input type="text" id="merchantId" name="merchantId" value=""  >
				
              </div>
            </div>
          

          <div class="row">
              <div class="col-50">
               <label for="fname"><i class="fa fa-user"></i> Client Transaction Id</label>
               <input type="text" id="clientid" name="clientid" value="<?php echo getDateTime();  ?>" >
              </div>
              <div class="col-50">
                <label for="zip">Amount</label>
                <input type="text" id="amount" name="amount"  value="1.5" >
              </div>
            </div>
          
			<div class="row">
              <div class="col-50">
               <label for="fname"><i class="fa fa-user"></i>Currency Code</label>
               <input type="text" id="currency" name="currency"  value="INR" readonly>
              </div>
              <div class="col-50">
                <label for="zip">Page ID / Config ID</label>
				
                <input type="text" id="pageid" name="pageid"  value="">
				
              </div>
            </div>
			
			 <div class="row">
              <div class="col-50">
               <label for="fname"><i class="fa fa-user"></i> Transaction_Key</label>
			   
               <input type="text" id="key" name="key"  value="" >
			  
              </div>
              <div class="col-50">
                <label for="zip"><i class="fa fa-user"></i> Transaction_IV</label>
				 
                <input type="text" id="iv" name="iv"  value="" >
				
              </div>
			  </div>
			  
			  <div class="row">
			   <div class="col-50">
                <label for="zip"><i class="fa fa-user"></i> Result_URL</label>
				
				 <input type="text" id="resulturl" name="resulturl"  value="" >
              </div>
			  <div class="col-50">
                <label for="zip"><i class="fa fa-user"></i> Environment</label>
               
				<input type="text" id="env" name="env"  value="" >	
              </div>
			   </div>
			  
			  <div class="row">
			  <div class="col-50">
                <label for="zip"><i class="fa fa-user"></i> Redirect_url</label>
               
				<input type="text" id="redirecturl" name="redirecturl"  value="" >
			  
			 </div> 
            </div>
			
			
         </div> 
        </div>
       
        <input type="submit" value="Continue to checkout" class="btn" name="submit">
      </form>
    </div>
  </div>

 
</div>
<style>
.row {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  margin: 0 -16px;
}

.col-25 {
  -ms-flex: 25%; /* IE10 */
  flex: 25%;
}

.col-50 {
  -ms-flex: 50%; /* IE10 */
  flex: 50%;
}

.col-75 {
  -ms-flex: 75%; /* IE10 */
  flex: 75%;
}

.col-25,
.col-50,
.col-75 {
  padding: 0 16px;
}

.container {
  background-color: #f2f2f2;
  padding: 5px 20px 15px 20px;
  border: 1px solid lightgrey;
  border-radius: 3px;
}

input[type=text] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

select{
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

label {
  margin-bottom: 10px;
  display: block;
}

.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 24px;
}

.btn {
  background-color: #4CAF50;
  color: white;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: #45a049;
}

span.price {
  float: right;
  color: grey;
}

/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other (and change the direction - make the "cart" column go on top) */
@media (max-width: 800px) {
  .row {
    flex-direction: column-reverse;
  }
  .col-25 {
    margin-bottom: 20px;
  }
}
</style>

        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/3.1.9-1/crypto-js.min.js" />
		   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

<script type="text/javascript">
	                   
		function dsstore() 
		{
                var mid = document.getElementById("merchantidd");
                var displayedmid=mid.options[mid.selectedIndex].value;
                document.getElementById("merchantid").value=displayedmid;
                
				var pageId = document.getElementById("pageidd");
                var displayedpageId=pageId.options[pageId.selectedIndex].value;
                document.getElementById("pageid").value=displayedpageId;
				
				var Key = document.getElementById("keyy");
                var displayedKey=Key.options[Key.selectedIndex].value;
                document.getElementById("key").value=displayedKey;
                
				var Ivv = document.getElementById("ivv");
                var displayedIvv=Ivv.options[Ivv.selectedIndex].value;
                document.getElementById("iv").value=displayedIvv;
                
			   
			   
		}
		
		document.getElementById("merchantidd").addEventListener("change", function () {
    var selectedStore = this.value;
    
    var merchantIdField = document.getElementById("merchantId");
    var pageidField = document.getElementById("pageid");
    var keyField = document.getElementById("key");    
    var ivField = document.getElementById("iv");
    var resulturlField = document.getElementById("resulturl");
    var redirecturlField = document.getElementById("redirecturl");
    var envField = document.getElementById("env");
   
console.log("Selected MID:", selectedStore);
    if (selectedStore === "470000000255972") {
        merchantIdField.value = "470000000255972";
		pageidField.value = "PageId2019120415869";		
        keyField.value = "kCTAu4TOmirjC0BiJXuM3wORDsm03ITpsDpZYbZ0TTE=";
        ivField.value = "dLZmkqqFBGmnJ2LtLIY0fA==";
        resulturlField.value = "http://127.0.0.1:8080/PHP/sampleTestResultprod.php";
        redirecturlField.value = "https://www.fdconnect.com/Pay/";
        envField.value = "https://www.fdconnect.com/FDConnectL3Services/getToken";

    } else if (selectedStore === "470000014671551") {
        merchantIdField.value = "470000014671551";
		pageidField.value = "PageId2022021713165";
        keyField.value = "d+jmahjqZzygfVmhZdyeOuzB4SuT7r7n2FYIo1/61F8=";
        ivField.value = "QXz06BpZP9K82LVIl2i6qA==";
        resulturlField.value = "http://127.0.0.1:8080/PHP/sampleTestResultuat.php";
        redirecturlField.value = "https://test.fdconnect.com/Pay/";
        envField.value = "https://test.fdconnect.com/FirstPayL2Services/getToken";
       
    } else {
        merchantIdField.value = "";
        pageidField.value = "";
        keyField.value = "";
        ivField.value = "";
        resulturlField.value = "";
        redirecturlField.value = "";
        envField.value = "";
    }
   
});
            
</script>
