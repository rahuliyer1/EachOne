<?php

namespace PaymentGateway;

ini_set('display_errors', 1);
error_reporting(E_ALL);



require_once 'FirstPayRefundRequest.php';
require_once 'FirstPayInquiryRequest.php';
require_once 'FirstPayRefundResponse.php';
require_once 'FirstPayInquiryResponse.php';
require_once('firstPayFormRequest.php');
$firstPayRefundRequest =  new FirstPayRefundRequest();
$firstPayInquiryRequest = new FirstPayInquiryRequest();
$bsObj = new \firstPayForm();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle the form submission
    $firstPayInquiryRequest->merchantTxnId = $_POST["merchantTxnId"];
    $firstPayInquiryRequest->fpTransactionId = $_POST["fpTransactionId"];
    $firstPayInquiryRequest->key = $_POST["key"];
    $firstPayInquiryRequest->iv = $_POST["iv"];
    $firstPayInquiryRequest->merchantId = $_POST["merchantId"];
	$firstPayInquiryRequest->fpURL =$_POST["fpURL"];
     $response1 = new \RootObject();



 $requestDataJSON = json_encode($firstPayInquiryRequest, JSON_PRETTY_PRINT);
 
 // Display the properly formatted JSON-like request data
echo "Request Data:" . json_encode($firstPayInquiryRequest) . "\n";
	$response1 = json_decode($bsObj->inquiry($firstPayInquiryRequest));

 if (json_last_error() !== JSON_ERROR_NONE) {
        echo json_encode(array(
            "status" => "error",
            "message" => "Error decoding JSON response: " . json_last_error_msg()
        ));
    } else {
        header('Content-Type: application/json');
		//echo $response1;
         //echo json_encode($response1, JSON_PRETTY_PRINT);
		   echo json_encode($response1);
    }
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Payment Gateway</title>
  
	
	<style>
	h1,td,input,div,textarea,button {
   
  background-color: #4CAF50; 
  color: white;
  
 
}

 input {
        width: 85%; /* Set the table's width to 100% of its container */
    }
 table {
        width: 75%; /* Set the table's width to 100% of its container */
    }
 select {
        width: 10%; /* Set the table's width to 100% of its container */
    }
	</style>
</head>
<body>
<h1 align="center">Transaction Inquiry</h1>
<form method="post">
    <table border="1">
        <tr>
            <td><label for="merchantTxnId">Merchant Transaction ID:</label></td>
            <td><input type="text" name="merchantTxnId" id="merchantTxnId" value="20231018212025">
		
			
			</td>
        </tr>
        <tr>
            <td><label for="fpTransactionId">FP Transaction ID:</label></td>
            <td><input type="text" name="fpTransactionId" id="fpTransactionId" value="2023101815090030"></td>
        </tr>
		<tr>
            <td><label for="merchantId">Merchant ID:</label></td>
            <td><input type="text" name="merchantId" id="merchantId" value="">
			<select id="merchantidd" name="merchantidd">
						<option value="" selected>Select MID...</option>
                        <option value="470000000255972" >470000000255972_PROD</option>
                        <option value="470000014671551" >470000014671551_UAT</option>
			</select>
			</td>
        </tr>
        <tr>
            <td><label for="key">Key:</label></td>
            <td><input type="text" name="key" id="key" value=""></td>
        </tr>
        <tr>
            <td><label for="iv">IV:</label></td>
            <td><input type="text" name="iv" id="iv" value=""></td>
        </tr>
        <tr>
            <td><label for="fpURL">fpURL:</label></td>
            <td><input type="readonly" name="fpURL" id="fpURL" value=""></td>
        </tr>
        <tr>
           <td colspan="2" align="center"><input type="submit" value="Submit"></td> 
        </tr>
    </table>
</form>

<div id="response-container" style="position: relative;">
    <textarea id="response-textarea" rows="30" style="width: 100%;">Inquiry Response:</textarea>
		<button type="button" onclick="copyToClipboard('response-textarea', this)" style="position: absolute; bottom: 0; right: 0;">Copy</button>
</div>
<button type="button" id="clearResponse" onclick="clearResponse()">Clear Response</button>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        // Find the response container element
        const responseContainer = document.getElementById("response-textarea");

        // Handle form submission using AJAX
        const form = document.querySelector("form");
        form.addEventListener("submit", function (event) {
            event.preventDefault(); // Prevent the form from submitting normally

            // Create a new FormData object from the form
            const formData = new FormData(form);

            // Send a POST request with the form data to your PHP script
            fetch("http://127.0.0.1:8080/PHP/Inquiry.php", {
                method: "POST",
                body: formData,
            })
                .then((response) => response.text())
                .then((data) => {
                    // Update the response container with the API response
					const modifiedResponse = `${data}`;
                responseContainer.innerHTML = modifiedResponse;
                    //responseContainer.value = JSON.stringify(data, null, 2);
                })
                .catch((error) => {
                    console.error("Error fetching API response:", error);
					responseContainer.value = "Error fetching API response: " + error.message;
					
                });
        });
    });
	
	
	document.getElementById("merchantidd").addEventListener("change", function () {
    var selectedStore = this.value;
    
    var merchantIdField = document.getElementById("merchantId");
    var keyField = document.getElementById("key");    
    var ivField = document.getElementById("iv");
    var fpURLField = document.getElementById("fpURL");
   

    if (selectedStore === "470000000255972") {
        merchantIdField.value = "470000000255972";
        keyField.value = "kCTAu4TOmirjC0BiJXuM3wORDsm03ITpsDpZYbZ0TTE=";
        ivField.value = "dLZmkqqFBGmnJ2LtLIY0fA==";
        fpURLField.value = "https://www.fdconnect.com/FDConnectL3Services/getTxnInquiryDetail";

    } else if (selectedStore === "470000014671551") {
        merchantIdField.value = "470000014671551";
        keyField.value = "d+jmahjqZzygfVmhZdyeOuzB4SuT7r7n2FYIo1/61F8=";
        ivField.value = "QXz06BpZP9K82LVIl2i6qA==";
        fpURLField.value = "https://test.fdconnect.com/FirstPayL2Services/getTxnInquiryDetail";
       
    } else {
        merchantIdField.value = "";
        keyField.value = "";
        ivField.value = "";
        fpURLField.value = "";
    }
   
});

function copyToClipboard(fieldId, button) {
                var fieldValue = document.getElementById(fieldId).value;

                // Create a temporary textarea element
                var tempTextarea = document.createElement("textarea");
                tempTextarea.value = fieldValue;

                // Append the textarea to the document
                document.body.appendChild(tempTextarea);

                // Select the content of the textarea
                tempTextarea.select();
                tempTextarea.setSelectionRange(0, 99999); // For mobile devices

                // Copy the selected text
                document.execCommand("copy");

                // Remove the temporary textarea
                document.body.removeChild(tempTextarea);
                // Create a tooltip element
  var tooltip = document.createElement("span");
  tooltip.innerText = "Copied!";
  tooltip.className = "tooltip";

  // Position the tooltip next to the copy button
  var rect = button.getBoundingClientRect();
  tooltip.style.top = rect.top + "px";
  tooltip.style.left = rect.left + "px";

  // Append the tooltip to the document
  document.body.appendChild(tooltip);

  // Remove the tooltip after 2 seconds
  setTimeout(function() {
    document.body.removeChild(tooltip);
  }, 2000);
}

function clearResponse() {
    document.getElementById("response-textarea").value = "";
}

</script>

</body>
</html>
